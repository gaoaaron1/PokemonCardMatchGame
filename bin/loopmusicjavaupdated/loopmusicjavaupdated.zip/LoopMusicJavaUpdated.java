package loopmusicjavaupdated;

public class LoopMusicJavaUpdated {

	public static void main(String[] args) {
		
		String filepath = ("C:\\Users\\aaron\\eclipse-workspace\\CardGame\\src\\Poketheme.wav");
		
		musicStuff musicObject = new musicStuff();
		musicObject.playMusic(filepath);
	}
}
