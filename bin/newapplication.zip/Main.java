
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;

import javax.swing.JFrame;

import javax.swing.JPanel;

import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class Main extends JFrame {
	
	public Main() {
		JPanel panel = new JPanel();
		
		setTitle("Tutorial");
		
        Pane gameWindow = new Pane();
        gameWindow.setPrefSize(802,802);
		setSize(820, 820);
		setResizable(false);
		
		Menu menu = new Menu();
		add(menu);
		
		/*
		panel.setBackground(java.awt.Color.DARK_GRAY);
		CustomButton button = new CustomButton("Customized");
		panel.add(button);
		add(panel);
		*/
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new Main();
		
	}


	public void start(Stage primaryStage, Pane gameWindow) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}